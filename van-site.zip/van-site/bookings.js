window.VAN_BOOKINGS = [];
